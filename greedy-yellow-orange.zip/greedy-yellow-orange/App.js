import React from 'react'
import { Text, SafeAreaView, StyleSheet, TextInput, Button } from 'react-native';

// You can import supported modules from npm
import { Card } from 'react-native-paper';

// or any files within the Snack
import AssetExample from './components/AssetExample';

export default function App() {
  const [text, onChangeText] = React.useState('');
  const [password, onChangePassword] = React.useState('');
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.paragraph}>
        Login: 
      </Text>
      <TextInput
        style={styles.input}
        onChangeText={onChangeText}
        value={text}
        placeholder="example@email.com"
        placeholderTextColor="gray"
      />
      <Text style={styles.paragraph}>
        Senha: 
      </Text>
      <TextInput
        style={styles.input}
        onChangeText={onChangePassword}
        value={password}
        placeholder="12345@Ab"
        placeholderTextColor="gray"
        secureTextEntry={true}
      />
      <Button
        style={styles.button}
        title="Logar"
        onPress={() => Alert.alert('Simple Button pressed')}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    marginTop: 20 ,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  }, 
  input: {
    height: 40,
    margin: 30,
    marginBottom: 20,
    marginTop: 5,
    borderWidth: 1,
    borderRadius: 5,
    padding: 10,
  },
  button: {
    height: 40,
    margin: 30,
    marginBottom: 20,
    marginTop: 5,
    borderWidth: 1,
    borderRadius: 5,
    padding: 10,
  },
});
